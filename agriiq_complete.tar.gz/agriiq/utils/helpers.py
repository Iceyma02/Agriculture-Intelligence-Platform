"""
AgriIQ — Shared Utilities
Data loading, chart theming, common helpers
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import os

# ── Path helper ───────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data", "csv")

# ── Chart theme ───────────────────────────────────────────────────────────────
CHART_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="DM Sans", color="#86efac", size=12),
    margin=dict(l=0, r=0, t=30, b=0),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(34,197,94,0.2)", borderwidth=1, font=dict(color="#86efac")),
    xaxis=dict(gridcolor="rgba(34,197,94,0.07)", linecolor="rgba(34,197,94,0.15)", tickfont=dict(color="#6b7280")),
    yaxis=dict(gridcolor="rgba(34,197,94,0.07)", linecolor="rgba(34,197,94,0.15)", tickfont=dict(color="#6b7280")),
    colorway=["#22c55e", "#a3e635", "#f59e0b", "#38bdf8", "#8b5cf6", "#f472b6", "#ef4444", "#fb923c"],
)

GREEN  = "#22c55e"
LIME   = "#a3e635"
AMBER  = "#f59e0b"
RED    = "#ef4444"
BLUE   = "#38bdf8"
PURPLE = "#8b5cf6"
PINK   = "#f472b6"
ORANGE = "#fb923c"

PALETTE = [GREEN, LIME, AMBER, BLUE, PURPLE, PINK, RED, ORANGE]

def apply_theme(fig, height=320):
    fig.update_layout(**CHART_LAYOUT, height=height)
    return fig

def card(children, style=None):
    from dash import html
    base = {"background": "#111811", "border": "1px solid rgba(34,197,94,0.15)",
            "borderRadius": "12px", "padding": "20px"}
    if style:
        base.update(style)
    return html.Div(children, style=base)

def kpi(value, label, delta=None, delta_up=True, color="#22c55e"):
    from dash import html
    delta_el = html.Div(delta, style={"fontSize": "0.78rem", "marginTop": "6px",
                                       "color": "#22c55e" if delta_up else "#ef4444"}) if delta else None
    return html.Div([
        html.Div(value, style={"fontFamily": "'Playfair Display',serif", "fontSize": "1.85rem",
                                "fontWeight": "700", "color": color, "lineHeight": "1"}),
        html.Div(label, style={"color": "#4ade80", "fontSize": "0.73rem", "textTransform": "uppercase",
                                "letterSpacing": "0.08em", "marginTop": "6px"}),
        *([delta_el] if delta_el else []),
    ], style={"background": "#151e15", "border": "1px solid rgba(34,197,94,0.15)",
               "borderRadius": "10px", "padding": "18px 20px"})

def page_header(title, subtitle=""):
    from dash import html
    return html.Div([
        html.H2(title, style={"fontFamily": "'Playfair Display',serif", "fontSize": "2rem",
                               "fontWeight": "700", "color": "#f0fdf4"}),
        html.P(subtitle, style={"color": "#4ade80", "fontSize": "0.85rem", "marginTop": "4px"}),
    ], style={"marginBottom": "28px"})

def status_badge(status):
    from dash import html
    colors = {"OK": ("#22c55e", "rgba(34,197,94,0.12)"),
              "Low": ("#f59e0b", "rgba(245,158,11,0.12)"),
              "Critical": ("#ef4444", "rgba(239,68,68,0.12)"),
              "Active": ("#22c55e", "rgba(34,197,94,0.12)"),
              "Suspended": ("#ef4444", "rgba(239,68,68,0.12)"),
              "HIGH": ("#ef4444", "rgba(239,68,68,0.12)"),
              "MEDIUM": ("#f59e0b", "rgba(245,158,11,0.12)"),
              "LOW": ("#22c55e", "rgba(34,197,94,0.12)"),
              "CRITICAL": ("#ef4444", "rgba(239,68,68,0.12)"),
              "Completed": ("#22c55e", "rgba(34,197,94,0.12)"),
              "In Transit": ("#38bdf8", "rgba(56,189,248,0.12)"),
              "Pending": ("#f59e0b", "rgba(245,158,11,0.12)"),
              }
    color, bg = colors.get(status, ("#86efac", "rgba(134,239,172,0.12)"))
    return html.Span(status, style={"background": bg, "color": color, "padding": "3px 10px",
                                     "borderRadius": "20px", "fontSize": "0.72rem", "fontWeight": "600"})

# ── Data loaders ──────────────────────────────────────────────────────────────

def _load(name):
    path = os.path.join(DATA_DIR, f"{name}.csv")
    return pd.read_csv(path)

def farms():          return _load("farms")
def monthly():        return _load("monthly_performance")
def pnl():            return _load("pnl")
def inventory():      return _load("inventory")
def movement():       return _load("harvest_movement")
def forecast():       return _load("yield_forecast")
def reorder():        return _load("reorder_optimizer")
def supply_chain():   return _load("supply_chain")
def sup_credit():     return _load("supplier_credit")
def marketing():      return _load("marketing_roi")
def market_prices():  return _load("market_prices")
def buyer_sat():      return _load("buyer_satisfaction")
def labour():         return _load("labour")
def losses():         return _load("losses")
def economic():       return _load("economic_watch")
def board():          return _load("board_summary")
def weather():        return _load("weather")

def fmt_usd(val):
    if val >= 1_000_000:
        return f"${val/1_000_000:.1f}M"
    if val >= 1_000:
        return f"${val/1_000:.0f}K"
    return f"${val:,.0f}"

def fmt_pct(val):
    return f"{val:.1f}%"

def fmt_tons(val):
    if val >= 1000:
        return f"{val/1000:.1f}K t"
    return f"{val:.0f} t"
